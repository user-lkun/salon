<?php
/**
 * Created by PhpStorm.
 * User: 35482
 * Date: 2018/6/2
 * Time: 10:50
 */

namespace Application\Controller\Home;


use Framework\Controller;
use Framework\Tools\PlatformController;

class IndexController extends Controller
{


    public function index()
    {
        @session_start();
        $this->display('index');
    }

}